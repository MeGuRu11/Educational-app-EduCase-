"""
main.py — Точка входа EduCase

Последовательность запуска:
    1. QApplication + иконка + шрифты
    2. SplashScreen.start()          ← появляется немедленно
    3. run_migrations()              ← Alembic upgrade head (~200ms)
    4. build_container()             ← DI: repos + services
    5. run_maintenance() отложено    ← VACUUM, cleanup (через 3с)
    6. LoginWindow создаётся заранее
    7. QTimer гарантирует ≥2500ms splash → splash.finish(login)
"""
import sys
import time

from PySide6.QtWidgets import QApplication
from PySide6.QtGui     import QIcon, QFontDatabase
from PySide6.QtCore    import QTimer

from config                   import _init_dirs
from core.database            import run_migrations
from core.di_container        import build_container
from core.db_maintenance      import run_maintenance
from core.thread_pool         import run_async
from ui.windows.splash_window import SplashScreen


def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName("EduCase")
    app.setApplicationVersion("1.0.0")

    # Иконка приложения (таскбар + Alt+Tab)
    app.setWindowIcon(QIcon("assets/icon.ico"))

    # 0. Создать директории данных (%APPDATA%/EduCase/...)
    _init_dirs()

    # 1. Загрузить шрифт (для корректного рендера ДО splash)
    QFontDatabase.addApplicationFont("assets/fonts/SegoeUIVariable.ttf")

    # 2. Splash — показываем НЕМЕДЛЕННО, до тяжёлых операций
    splash = SplashScreen()
    splash.start()
    t_start = time.monotonic()
    app.processEvents()

    # 3. Миграции БД (синхронно, обычно < 200ms)
    run_migrations()
    app.processEvents()

    # 4. DI-контейнер (все репозитории и сервисы)
    container = build_container()
    app.processEvents()

    # 5. Фоновое обслуживание БД — откладываем на 3с после старта
    #    (VACUUM/checkpoint не должны мешать первому экрану)
    QTimer.singleShot(3000, lambda: run_async(run_maintenance))

    # 6. LoginWindow — создаём заранее, но НЕ показываем
    from ui.windows.login_window import LoginWindow
    login = LoginWindow(container)

    # 7. Гарантируем минимум 2500ms показа splash
    #    Если миграции + DI заняли > 2500ms — delay=0, закрываем сразу
    elapsed_ms = int((time.monotonic() - t_start) * 1000)
    delay_ms   = max(0, 2500 - elapsed_ms)
    QTimer.singleShot(delay_ms, lambda: splash.finish(login))

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
